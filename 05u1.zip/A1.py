from datetime import datetime

def parse_time(time_str):
    return datetime.strptime(time_str, "%H:%M")

def format_time(time_obj):
    return time_obj.strftime("%H:%M")

def detect_conflicts(events):
    events.sort(key=lambda x: x['start'])
    conflicts = []
    for i in range(len(events) - 1):
        if events[i]['end'] > events[i + 1]['start']:
            conflicts.append((events[i], events[i + 1]))
    return conflicts

def suggest_alternative(event, events, working_hours):
    start_of_day, end_of_day = parse_time(working_hours[0]), parse_time(working_hours[1])
    events.sort(key=lambda x: x['start'])
    potential_start = start_of_day
    for e in events:
        if potential_start + (event['end'] - event['start']) <= e['start']:
            return {
                "description": event['description'],
                "start": format_time(potential_start),
                "end": format_time(potential_start + (event['end'] - event['start']))
            }
        potential_start = max(potential_start, e['end'])
    if potential_start + (event['end'] - event['start']) <= end_of_day:
        return {
            "description": event['description'],
            "start": format_time(potential_start),
            "end": format_time(potential_start + (event['end'] - event['start']))
        }
    return None

events = []
n = int(input("Enter the number of events: "))
for _ in range(n):
    description = input("Enter event description: ")
    start = parse_time(input("Enter start time (HH:MM): "))
    end = parse_time(input("Enter end time (HH:MM): "))
    events.append({"description": description, "start": start, "end": end})

working_hours = input("Enter working hours (start and end separated by a space, e.g., 08:00 18:00): ").split()
conflicts = detect_conflicts(events)

print("Sorted Schedule:")
for event in sorted(events, key=lambda x: x['start']):
    print(f'"{event["description"]}", Start: "{format_time(event["start"])}", End: "{format_time(event["end"])}"')

if conflicts:
    print("\nConflicting Events:")
    for e1, e2 in conflicts:
        print(f'"{e1["description"]}" and "{e2["description"]}"')
    print("\nSuggested Resolutions:")
    for _, e2 in conflicts:
        alternative = suggest_alternative(e2, events, working_hours)
        if alternative:
            print(f'Reschedule "{e2["description"]}" to Start: "{alternative["start"]}", End: "{alternative["end"]}"')
else:
    print("\nNo conflicts detected.")
