const {
    Client,
    TokenCreateTransaction,
    TokenType,
    TokenSupplyType,
    Hbar,
    AccountCreateTransaction,
    AccountBalanceQuery,
    TransferTransaction,
    TokenMintTransaction,
    PrivateKey,
    AccountId
} = require("@hashgraph/sdk");

const fs = require("fs"); // Importing fs module

const client = Client.forTestnet(); // Or use Client.forMainnet() for production

// Set your private key for treasury and sender
const treasuryPrivateKey = PrivateKey.fromString("your-treasury-private-key");
const treasuryAccountId = treasuryPrivateKey.publicKey.toAccountId();
const recipientAccountId = AccountId.fromString("recipient-account-id");

// Create the Fungible Token
async function createToken() {
    const tokenCreateTx = new TokenCreateTransaction()
        .setTokenName("MyToken")
        .setTokenSymbol("MTK")
        .setDecimals(2)  // Token with two decimal places
        .setInitialSupply(1000)
        .setTreasuryAccountId(treasuryAccountId)
        .setTokenType(TokenType.Fungible)
        .setSupplyType(TokenSupplyType.Infinite) // Infinite supply
        .setMaxTransactionFee(new Hbar(2)); // Max transaction fee

    const tokenCreateTxResponse = await tokenCreateTx.execute(client);
    const tokenCreateReceipt = await tokenCreateTxResponse.getReceipt(client);

    const tokenId = tokenCreateReceipt.tokenId;
    console.log(`Token Created: ${tokenId.toString()}`);

    // Save token details (name and ID) to a file
    const tokenDetails = `Token Created: ${tokenId.toString()}\nToken Name: MyToken\nToken Symbol: MTK\n`;
    fs.writeFileSync("token_details.txt", tokenDetails);  // Save to file

    return tokenId;
}

// Transfer Fungible Token from Treasury to Recipient
async function transferTokens(tokenId, amount) {
    const transferTx = new TransferTransaction()
        .addTokenTransfer(tokenId, treasuryAccountId, -amount)
        .addTokenTransfer(tokenId, recipientAccountId, amount)
        .setMaxTransactionFee(new Hbar(1)); // Max transaction fee

    const transferTxResponse = await transferTx.execute(client);
    const transferReceipt = await transferTxResponse.getReceipt(client);
    console.log(`Transferred ${amount} tokens from Treasury to Recipient`);
}

// Mint Additional Tokens
async function mintTokens(tokenId, amount) {
    const mintTx = new TokenMintTransaction()
        .setTokenId(tokenId)
        .setAmount(amount)
        .setMaxTransactionFee(new Hbar(1)); // Max transaction fee

    const mintTxResponse = await mintTx.execute(client);
    const mintReceipt = await mintTxResponse.getReceipt(client);
    console.log(`Minted ${amount} additional tokens`);
}

async function main() {
    const tokenId = await createToken();

    // Transfer 50 tokens from the treasury to the recipient
    await transferTokens(tokenId, 50);

    // Mint and distribute 500 tokens
    await mintTokens(tokenId, 500);
    await transferTokens(tokenId, 100); // Transfer to Account1
    await transferTokens(tokenId, 200); // Transfer to Account2
    await transferTokens(tokenId, 150); // Transfer to Account3
}

main().catch(console.error);
